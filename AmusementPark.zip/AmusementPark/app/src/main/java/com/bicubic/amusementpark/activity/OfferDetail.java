package com.bicubic.amusementpark.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.bicubic.amusementpark.R;

public class OfferDetail extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offer_detail);


    }


}
